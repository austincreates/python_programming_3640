from mypolygon import square, polygon
import turtle

alex= turtle.Turtle()

polygon(alex,3, 200)

turtle.mainloop()