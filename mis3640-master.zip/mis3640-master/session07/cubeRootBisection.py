cube = 54
epsilon = 0.01
num_guesses = 0
low = 0
high = cube
guess = (high + low) / 2.0

''' finish the following while block 
while ...



'''


print('num_guesses =', num_guesses)
print(guess, 'is close to the cube root of', cube)
